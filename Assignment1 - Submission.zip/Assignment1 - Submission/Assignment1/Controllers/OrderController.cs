﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Assignment1.Models;
using Assignment1.DAL;
using System.Data;

namespace Assignment1.Controllers
{
   

    public class OrderController : Controller
    {
         private IOrderRepository _orderRepository;
         public OrderController()
         {
             this._orderRepository = new OrderRepository(new OrderContext());
         }  
        //
        // GET: /Order/

        public ActionResult Index()
        {
            var orders = from Item in _orderRepository.GetAll()
                        select Item;
            return View(orders); 
        }

        public ViewResult Details(int Id)
        {
            Order orderbyid = _orderRepository.Get(Id);
            return View(orderbyid);
        }  
        public ActionResult Create()
        {
            return View(new Order());
        }
        [HttpPost]
        public ActionResult Create(Order Item)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _orderRepository.Add(Item);
                    _orderRepository.Save(); 
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(Item);
        }


        public ActionResult Edit(int Id)
        {
            Order order = _orderRepository.Get(Id);
            return View(order);
        }
        [HttpPost]
        public ActionResult Edit(Order Item)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _orderRepository.Update(Item);
                    _orderRepository.Save();  
                    return RedirectToAction("Index");
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }
            return View(Item);
        }

        public ActionResult Delete(int Id, bool? saveChangesError)
        {
            if (saveChangesError.GetValueOrDefault())
            {
                ViewBag.ErrorMessage = "Unable to save changes. Try again, and if the problem persists see your system administrator.";
            }
            Order order = _orderRepository.Get(Id);
            return View(order);
        }
        [HttpPost, ActionName("Delete")]
        public ActionResult Delete(int Id)
        {
            try
            {
                Order order = _orderRepository.Get(Id);
                _orderRepository.Remove(Id);
                _orderRepository.Save();
            }
            catch (DataException)
            {
                return RedirectToAction("Delete",
                   new System.Web.Routing.RouteValueDictionary {  
        { "id", Id },  
        { "saveChangesError", true } });
            }
            return RedirectToAction("Index");
        }  
    }
}
