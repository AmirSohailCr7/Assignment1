﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Assignment1.Models
{
    public class Order
    {
        [Key]
        public int OrdId { get; set; }
        [Required]
        [MaxLength(30)]
        public string CusName { get; set; }
        public int Laptop { get; set; }
        public int LCD { get; set; }
        public int Phone { get; set; }

    }
}