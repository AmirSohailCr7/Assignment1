﻿using Assignment1.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using Assignment1.DAL;



namespace Assignment1.DAL
{
    public class OrderRepository : IOrderRepository
    {
        private OrderContext _context;  
        public OrderRepository(OrderContext ordercontext)  
        {  
            this._context = ordercontext;  
        }  
        public IEnumerable<Order> GetAll()  
        {  
            return _context.Orders.ToList();  
        }  
        public Order Get(int Id)  
        {
            return _context.Orders.Find(Id);  
        }  
        public void Add(Order Item)  
        {
            _context.Orders.Add(Item);  
        }  
        public void Remove(int Id)  
        {  
            Order order = _context.Orders.Find(Id);
            _context.Orders.Remove(order);  
        }
        public void Update(Order Item)
        {
            _context.Entry(Item).State = EntityState.Modified;
             
        }

        public void Save()
        {
            _context.SaveChanges();
        }  
        private bool disposed = false;  
        protected virtual void Dispose(bool disposing)  
        {  
            if (!this.disposed)  
            {  
                if (disposing)  
                {  
                    _context.Dispose();  
                }  
            }  
            this.disposed = true;  
        }  
        public void Dispose()  
        {  
            Dispose(true);  
            GC.SuppressFinalize(this);  
        }  

    }
}