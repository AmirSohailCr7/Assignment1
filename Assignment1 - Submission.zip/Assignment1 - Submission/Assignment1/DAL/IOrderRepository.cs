﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Assignment1.Models;


namespace Assignment1.DAL
{
    public interface IOrderRepository:IDisposable
    {
        IEnumerable<Order> GetAll();
        Order Get(int Id);
        void Add(Order Item);
        void Remove(int Id);
        void Update(Order Item);
        void Save();
    }
}