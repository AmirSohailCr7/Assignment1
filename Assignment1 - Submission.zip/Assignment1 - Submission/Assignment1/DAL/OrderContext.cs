﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Assignment1.Models; 

namespace Assignment1.DAL
{
    public class OrderContext : DbContext
    {
        public OrderContext()
            : base("name=DefaultConnection")
        {
        }
        public DbSet<Order> Orders { get; set; }
    }
   
}